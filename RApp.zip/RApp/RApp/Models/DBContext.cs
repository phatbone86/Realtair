﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace RApp.Models
{
    public partial class DBContext : DbContext
    {
        public virtual DbSet<UserDetails> UserDetails { get; set; }

        public virtual DbSet<TaskDetails> TaskDetails { get; set; }

        public DBContext(DbContextOptions<DBContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserDetails>(entity =>
            {
                entity.ToTable("UserAccount");

                entity.Property(e => e.FName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TaskDetails>(entity =>
            {
                entity.ToTable("Task");

                entity.Property(e => e.TaskID);

                entity.Property(e => e.UserID);

                entity.Property(e => e.Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                //entity.Property(e => e.Completed);
            });
        }
    }
}
