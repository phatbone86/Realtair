﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;

namespace RApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly DBContext _context;

        public AccountController(DBContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userdetails = await _context.UserDetails
                .SingleOrDefaultAsync(m => m.Email == model.Email && m.Password == model.Password);
                if (userdetails == null)
                {
                    ModelState.AddModelError("Password", "Invalid login attempt.");
                    return View("Index");
                }
                HttpContext.Session.SetString("userID", userdetails.UserID.ToString());
                HttpContext.Session.SetString("fName", userdetails.FName);
            }
            else
            {
                return View("Index");
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpPost]
        public async Task<ActionResult> Register(RegistrationViewModel model)
        {

            if (ModelState.IsValid)
            {
                UserDetails user = new UserDetails
                {
                    FName = model.FName,
                    LName = model.LName,
                    Email = model.Email,
                    Password = model.Password

                };
                _context.Add(user);
                await _context.SaveChangesAsync();

                var userdetails = await _context.UserDetails
                .SingleOrDefaultAsync(m => m.Email == model.Email && m.Password == model.Password);
                HttpContext.Session.SetString("userID", userdetails.UserID.ToString());
                HttpContext.Session.SetString("fName", model.FName);
            }
            else
            {
                return View("Registration");
            }
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Index");
        }
        public void ValidationMessage(string key, string alert, string value)
        {
            try
            {
                TempData.Remove(key);
                TempData.Add(key, value);
                TempData.Add("alertType", alert);
            }
            catch
            {
                Debug.WriteLine("TempDataMessage Error");
            }

        }
    }
}